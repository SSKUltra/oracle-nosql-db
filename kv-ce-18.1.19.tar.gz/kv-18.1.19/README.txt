Oracle NoSQL Database 18.1.19 Community Edition: 2018-09-12 09:31:32 UTC

This is Oracle NoSQL Database, version 18.1.19 Community Edition.

To view the release and installation documentation, load the
distribution file doc/index.html into your web browser.
